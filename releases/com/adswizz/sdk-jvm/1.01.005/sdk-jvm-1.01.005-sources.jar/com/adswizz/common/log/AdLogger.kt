package com.adswizz.common.log

import com.adswizz.common.extension.splitIntoChunks

// This class has proguard keep rules because is used (for now) in another internal modules
object AdLogger {
    private var cLogger: Logger? = null

    fun setLogger(logger: Logger?){
        cLogger = logger
    }

    fun log(type: LogType, tag: String, message: String) {
        if (cLogger != null) {
            cLogger?.log(type, tag, message)
        }
        else{
            when (type) {
                LogType.d -> println("$tag, $message")
                LogType.e -> println("$tag, $message")
                LogType.i -> println("$tag, $message")
                LogType.v -> println("$tag, $message")
                LogType.w -> println("$tag, $message")
            }
        }
    }

    fun logCritical(message: String){
        log(LogType.e, "Critical", message)
        println("\r\n")
        println("*".repeat(88))
        message.splitIntoChunks(80).forEach {
            println("*** $it ***")
        }
        println("*".repeat(88))
        println("\r\n")
    }
}