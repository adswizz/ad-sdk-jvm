package com.adswizz.sdk

import com.ad.core.adData.Payload
import com.ad.core.adData.internal.AdDataSimple
import com.ad.core.adData.internal.ImpressionsAndTrackingsReporting
import com.ad.core.adData.internal.TrackingUrl
import com.ad.core.macro.MacroContext
import com.adswizz.common.macro.VASTErrorCode

@Suppress("unused")
class AdswizzTrackingEngine {

    private val impressionsAndTrackingsReporting = ImpressionsAndTrackingsReporting()

    fun started(key: String, payload: ByteArray, elapsedTime: Double, macroContext: MacroContext?): ByteArray{
        val adData = getAdDataFromKey(payload)
        impressionsAndTrackingsReporting.reportImpressions(
            adData,
            macroContext
        )
        println("*** Old macrocontext: ${adData.macroContext}")
        val newMacroContext = newMacroContext(adData, macroContext)
        println("*** New macrocontext: $newMacroContext")
        val newAdData = AdDataSimple(adData.id, adData.instanceId, adData.duration, emptyList(), adData.listTrackings, emptyList(),emptyList(), newMacroContext)
        return Payload.serializeToByteArray(newAdData)
    }

    fun error(key: String, payload: ByteArray, elapsedTime: Double, macroContext: MacroContext?): ByteArray {
        val adData = getAdDataFromKey(payload)
        impressionsAndTrackingsReporting.reportErrors(
            adData,
            VASTErrorCode.GENERAL_LINEAR_ERROR,
            macroContext
        )
        return payload
    }

    fun progress(key: String, payload: ByteArray, elapsedTime: Double, macroContext: MacroContext?): ByteArray{
        val adData = getAdDataFromKey(payload)
        println("*** Old macrocontext: ${adData.macroContext}")
        val newMacroContext = newMacroContext(adData, macroContext)
        println("*** New macrocontext: $newMacroContext")

        val newAdData = checkQuartile(adData, elapsedTime, newMacroContext)
        return Payload.serializeToByteArray(newAdData)
    }

    fun pause(key: String, payload: ByteArray, elapsedTime: Double, macroContext: MacroContext?): ByteArray{
        val adData = getAdDataFromKey(payload)
        println("*** Old macrocontext: ${adData.macroContext}")
        val newMacroContext = newMacroContext(adData, macroContext)
        println("*** New macrocontext: $newMacroContext")
        impressionsAndTrackingsReporting.reportOtherEvents(adData, "did_pause_playing", newMacroContext )
        val newAdData = adData.copy(macroContext = newMacroContext)

        return Payload.serializeToByteArray(newAdData)
    }

    fun resume(key: String, payload: ByteArray, elapsedTime: Double, macroContext: MacroContext?): ByteArray{
        var newPayload = payload
        getAdDataFromKey(payload).let { adData ->
            println("*** Old macrocontext: ${adData.macroContext}")
            val newMacroContext = newMacroContext(adData, macroContext)
            println("*** New macrocontext: $newMacroContext")
            impressionsAndTrackingsReporting.reportOtherEvents(adData, "did_resume_playing", newMacroContext )
            val newAdData = adData.copy(macroContext = newMacroContext)
            newPayload = Payload.serializeToByteArray(newAdData)
        }
        return newPayload
    }

    fun event(key: String, payload: ByteArray, elapsedTime: Double, event: String, macroContext: MacroContext?): ByteArray {
        var newPayload = payload
        getAdDataFromKey(payload).let { adData ->
            println("*** Old macrocontext: ${adData.macroContext}")
            val newMacroContext = newMacroContext(adData, macroContext)
            println("*** New macrocontext: $newMacroContext")
            impressionsAndTrackingsReporting.reportOtherEvents(adData, event, newMacroContext )
            val newAdData = adData.copy(macroContext = newMacroContext)
            newPayload =  Payload.serializeToByteArray(newAdData)
        }
        return newPayload
    }

    fun ended(key: String, payload: ByteArray, elapsedTime: Double, reason: String, macroContext: MacroContext?): ByteArray{
        val adData = getAdDataFromKey(payload)
        println("*** Old macrocontext: ${adData.macroContext}")
        val newMacroContext = newMacroContext(adData, macroContext)
        println("*** New macrocontext: $newMacroContext")
        triggerEventsOnPlayPercent(adData, 1.0, macroContext)
        val newAdData = adData.copy(macroContext = newMacroContext)
        return Payload.serializeToByteArray(newAdData)
    }

    fun newMacroContext(adData: AdDataSimple, macroContext: MacroContext?): MacroContext? {
        if (macroContext == null) return null
        var needsUpdate = false
        val macroContextBuilder = MacroContext.Builder()

        //implement here the needs for update
        if ( adData.macroContext == null ){
            return macroContext
        }


        val timestamp = macroContext.timestamp ?: adData.macroContext.timestamp
        if (timestamp != null ){
            macroContextBuilder.withTimeStamp(timestamp)
            needsUpdate = true
        }

        val cacheBusting = macroContext.cacheBusting ?: adData.macroContext.cacheBusting
        if (cacheBusting != null){
            macroContextBuilder.withCacheBusting(cacheBusting)
            needsUpdate = true
        }

        val contentPlayHead = macroContext.contentPlayHead ?: adData.macroContext.contentPlayHead
        if (contentPlayHead != null){
            macroContextBuilder.withContentPlayHead(contentPlayHead)
            needsUpdate = true
        }

        val mediaPlayHead = macroContext.mediaPlayHead ?: adData.macroContext.mediaPlayHead
        if ( mediaPlayHead != null ){
            macroContextBuilder.withMediaPlayHead(mediaPlayHead)
            needsUpdate = true
        }

        val breakPosition = macroContext.breakPosition ?: adData.macroContext.breakPosition
        if ( breakPosition != null ){
            macroContextBuilder.withBreakPosition(breakPosition)
            needsUpdate = true
        }

        val blockedAdCategories = macroContext.blockedAdCategories ?: adData.macroContext.blockedAdCategories
        if ( blockedAdCategories != null ){
            macroContextBuilder.withBlockedAdCategories(blockedAdCategories)
            needsUpdate = true
        }

        val adCount = macroContext.adCount ?: adData.macroContext.adCount
        if ( adCount != null ){
            macroContextBuilder.withAdCount(adCount)
            needsUpdate = true
        }

        val transactionId = macroContext.transactionId ?: adData.macroContext.transactionId
        if ( transactionId != null ){
            macroContextBuilder.withTransactionId(transactionId)
            needsUpdate = true
        }

        val adType = macroContext.adType ?: adData.macroContext.adType
        if ( adType != null ){
            macroContextBuilder.withAdAdType(adType)
            needsUpdate = true
        }

        val ifa = macroContext.ifa ?: adData.macroContext.ifa
        if ( ifa != null ){
            macroContextBuilder.withIfa(ifa)
            needsUpdate = true
        }

        val ifaType = macroContext.ifaType ?: adData.macroContext.ifaType
        if ( ifaType != null ){
            macroContextBuilder.withIfa(ifaType)
            needsUpdate = true
        }

        val clientUA = macroContext.clientUA ?: adData.macroContext.clientUA
        if ( clientUA != null ){
            macroContextBuilder.withClientUserAgent(clientUA)
            needsUpdate = true
        }

        val deviceUA = macroContext.deviceUA ?: adData.macroContext.deviceUA
        if ( deviceUA != null ){
            macroContextBuilder.withDeviceUserAgent(deviceUA)
            needsUpdate = true
        }

        val serverSide = macroContext.serverSide ?: adData.macroContext.serverSide
        if ( serverSide != null ){
            macroContextBuilder.withServerSide(serverSide)
            needsUpdate = true
        }

        val appBundle = macroContext.appBundle ?: adData.macroContext.appBundle
        if ( appBundle != null ){
            macroContextBuilder.withAppBundle(appBundle)
            needsUpdate = true
        }

        val storeId = macroContext.storeId ?: adData.macroContext.storeId
        if ( storeId != null ){
            macroContextBuilder.withStoreId(storeId)
            needsUpdate = true
        }

        val vastVersions = macroContext.vastVersions ?: adData.macroContext.vastVersions
        if ( vastVersions != null ){
            macroContextBuilder.withVastVersions(vastVersions)
            needsUpdate = true
        }

        val playerCapabilities = macroContext.playerCapabilities ?: adData.macroContext.playerCapabilities
        if ( playerCapabilities != null ){
            macroContextBuilder.withPlayerCapabilities(playerCapabilities)
            needsUpdate = true
        }

        val playerState = macroContext.playerState ?: adData.macroContext.playerState
        if ( playerState != null ){
            macroContextBuilder.withPlayerState(playerState)
            needsUpdate = true
        }

        val adPlayHead = macroContext.adPlayHead ?: adData.macroContext.adPlayHead
        if ( adPlayHead != null ){
            macroContextBuilder.withAdPlayHead(adPlayHead)
            needsUpdate = true
        }

        val assetUri = macroContext.assetUri ?: adData.macroContext.assetUri
        if ( assetUri != null ){
            macroContextBuilder.withAssetUri(assetUri)
            needsUpdate = true
        }

        val adServingId = macroContext.adServingId ?: adData.macroContext.adServingId
        if ( adServingId != null ){
            macroContextBuilder.withAdServingId(adServingId)
            needsUpdate = true
        }

        val errorCode = macroContext.errorCode ?: adData.macroContext.errorCode
        if ( errorCode != null ){
            macroContextBuilder.withErrorCode(errorCode)
            needsUpdate = true
        }

        val limitAdTracking = macroContext.limitAdTracking ?: adData.macroContext.limitAdTracking
        if ( limitAdTracking != null ){
            macroContextBuilder.withLimitAdTrackingEnabled(limitAdTracking)
            needsUpdate = true
        }

        return if (needsUpdate) {
            macroContextBuilder.build()
        }
        else{
            null
        }
    }

    private fun getAdDataFromKey(payload: ByteArray): AdDataSimple {
        return Payload.deserializeFromByteArray(payload)
    }

    internal fun checkQuartile(adData: AdDataSimple, progress: Double, macroContext: MacroContext?): AdDataSimple{
            val adDuration = adData.duration
            val percent = progress/adDuration
            //old check checkCurrentAdQuartiles(adDuration.toDouble(DurationUnit.SECONDS))
            val removedEvents = triggerEventsOnPlayPercent(adData, percent, macroContext)
            if (removedEvents.isEmpty()){
                return adData
            }
            else{
                val listTrackingEvents = mutableListOf<TrackingUrl>()
                adData.listTrackings.forEach {
                    if ( removedEvents.find { removed->
                        removed.event ==  it.event
                    } == null ){
                       listTrackingEvents.add(it)
                    }
                }
                val newAdData = adData.copy(listTrackings = listTrackingEvents)
                return newAdData
            }
    }

    private fun triggerEventsOnPlayPercent(adData: AdDataSimple, playPercent:Double, macroContext: MacroContext?): List<TrackingUrl>{
        val positionsTriggered = impressionsAndTrackingsReporting.playHeadChanged(adData, playPercent)
        val listPositionsTriggered = mutableListOf<TrackingUrl>()
        positionsTriggered?.let {
            sendEventsForPositions(adData, positions = it, macroContext)
            listPositionsTriggered.addAll(it)
        }
        return listPositionsTriggered
    }

    private fun sendEventsForPositions(ad: AdDataSimple, positions: List<TrackingUrl>, macroContext: MacroContext?) {
        positions.forEach {
            impressionsAndTrackingsReporting.reportTrackings(
                ad,
                it,
                macroContext
            )
        }

    }
}