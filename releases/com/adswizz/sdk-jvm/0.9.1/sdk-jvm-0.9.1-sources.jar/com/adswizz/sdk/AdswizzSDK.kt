package com.adswizz.sdk

import com.ad.core.macro.internal.UrlEventDispatcher
import com.adswizz.common.Utils
import com.adswizz.common.analytics.AnalyticsCollector
import com.adswizz.common.analytics.AnalyticsEvent
import com.adswizz.common.analytics.internal.AnalyticsCollectorCore
import com.adswizz.common.log.AdLogger
import com.adswizz.common.log.LogType
import com.adswizz.common.log.Logger
import com.adswizz.core.zc.ZCManager
import com.adswizz.core.zc.model.ZCConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean


@Suppress("UNUSED")
object AdswizzSDK {

    fun interface SdkCompletion {
        fun onComplete()
    }

    @get:JvmSynthetic
    @field:JvmSynthetic
    internal val sharedInternal : AdswizzSDKSharedInternal = AdswizzSDKSharedInternalImpl()

    /**
     * Use this property to add your own AnalyticsConnector to receive all the events from the SDK and forward
     * them to your own ingestion pipeline (Firebase, Mixpanel etc.).
     *
     * AdswizzSDK keeps a strong reference to the AnalyticsConnector, so it's your responsibility
     * to handle lifecycle of the AnalyticsConnector instance while listening for analytics events
     */
    @JvmStatic
    val analytics: AnalyticsCollector? get() = sharedInternal.analytics

    /**
     * This property stores initialization status.
     * Use completion block of initialize function to be sure that initialization process of AdswizzSDK
     * completed.
     **/
    @JvmStatic
    val isInitialized: Boolean
        get(){
            return _isInitialized.get()
        }

    @JvmStatic
    var logger: Logger?
        set(value) {
            AdLogger.cLogger = value
        }
        get(){
            return AdLogger.cLogger
        }

    private var installationId: String? = null
    private var _isInitialized = AtomicBoolean(false)
    private var startInitializing = AtomicBoolean(false)
    private var startCleanup = AtomicBoolean(false)
    private lateinit var zcManager: ZCManager
    /**
     * SDK initialization. The recommended way to do this is in the main function of your application.
     * @param installationId: the installationId provided.
     * @param completion: optional completion callback which signals when [AdswizzSDK] is fully initialised.
     *
     */

    @JvmStatic
    fun initialize(installationId: String?, completion: SdkCompletion? = null) {
        if ( _isInitialized.get()) {
            AdLogger.logCritical("Adswizz SDK already initialized !")
            return
        }

        if (!startInitializing.compareAndSet(false, true)) {
            AdLogger.logCritical("Adswizz SDK didn't finished previous initialization !")
            return
        }

        if (installationId == null) {
            startInitializing.set(false)
            AdLogger.logCritical("Adswizz SDK cannot be initialised without installationId !")
            return
        }

        CoroutineScope(Dispatchers.IO).launch {

            this@AdswizzSDK.installationId = installationId

            // ZcManager will fetch configuration and modify the ModuleLifecycleManager modules based on zc config
            zcManager = ZCManager()
            val (zcResult, zcEvent) = zcManager.setInstallationId(installationId)
            if (!zcResult) {
                AdLogger.log(
                    LogType.w,
                    "AdswizzSDK",
                    "Unable to get the zc config file for the installationId \"$installationId\". The default values will be used."
                )
            }

            with(sharedInternal as AdswizzSDKSharedInternalImpl) {
                _analytics = AnalyticsCollectorCore(zcAnalytics = zcManager.zcConfig.analytics)
                _zcConfig = zcManager.zcConfig
                _urlEventDispatcher = UrlEventDispatcher()
            }

            _isInitialized.set(true)

            completion?.onComplete()

            startInitializing.set(false)

            sharedInternal.analytics?.log(zcEvent)

            sharedInternal.analytics?.log(
                AnalyticsEvent(
                    "sdk-initialize",
                    "LIFECYCLE",
                    AnalyticsCollector.Level.INFO,
                    mapOf("installationId" to installationId)
                )
            )

        }
    }

    /**
     * Perform SDK cleanup and release all SDK components.
     * Call it when you no longer need the SDK.
     */
    @JvmStatic
    fun cleanup() {
        if (!_isInitialized.get() ){
            AdLogger.logCritical("Adswizz SDK is not initialized !")
            return
        }

        if (!startCleanup.compareAndSet(false, true)) {
            AdLogger.logCritical("Adswizz SDK didn't finished previous cleanup !")
            return
        }

        zcManager.cleanup()

        installationId?.let {
            sharedInternal.analytics?.log(
                AnalyticsEvent(
                    "sdk-uninitialize",
                    "LIFECYCLE",
                    AnalyticsCollector.Level.INFO,
                    mapOf("installationId" to it)
                )
            )
        }

        _isInitialized.set(false)
        startCleanup.set(false)

        with(sharedInternal as AdswizzSDKSharedInternalImpl) {
            _analytics?.cleanup()
            _analytics = null
            _zcConfig = null
            _urlEventDispatcher?.cleanup()
            _urlEventDispatcher = null
        }

    }

    @JvmStatic
    fun getVersion() = Utils.SDKVersion

    private class AdswizzSDKSharedInternalImpl: AdswizzSDKSharedInternal {

        var _analytics: AnalyticsCollectorCore? = null
        var _zcConfig: ZCConfig? = null
        var _urlEventDispatcher: UrlEventDispatcher? = null

        override val analytics: AnalyticsCollectorCore? get() = _analytics

        override val zcConfig: ZCConfig? get() = _zcConfig

        override val urlEventDispatcher: UrlEventDispatcher? get() = _urlEventDispatcher

    }

}

internal interface AdswizzSDKSharedInternal{

    val analytics: AnalyticsCollectorCore?

    val zcConfig: ZCConfig?

    val urlEventDispatcher: UrlEventDispatcher?
}



