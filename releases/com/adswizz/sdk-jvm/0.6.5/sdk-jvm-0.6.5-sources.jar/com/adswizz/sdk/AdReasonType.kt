package com.adswizz.sdk

enum class AdReasonType {
    AD_CANCELLED,
    AD_COMPLETED,
    AD_SKIPPED,
    AD_SKIPPED_WITH_ERROR,
    OTHER
}