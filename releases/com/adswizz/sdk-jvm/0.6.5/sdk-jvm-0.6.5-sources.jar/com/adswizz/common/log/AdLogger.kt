package com.adswizz.common.log

import com.adswizz.common.extension.splitIntoChunks

internal object AdLogger {
    var cLogger: Logger? = null

    fun log(type: LogType, tag: String, message: String) {
        if (cLogger != null) {
            cLogger?.log(type, tag, message)
        }
        else{
            when (type) {
                LogType.d -> println("$tag, $message")
                LogType.e -> println("$tag, $message")
                LogType.i -> println("$tag, $message")
                LogType.v -> println("$tag, $message")
                LogType.w -> println("$tag, $message")
            }
        }
    }

    fun logCritical(message: String){
        log(LogType.e, "Critical", message)
        println("\r\n")
        println("*".repeat(88))
        message.splitIntoChunks(80).forEach {
            println("*** $it ***")
        }
        println("*".repeat(88))
        println("\r\n")
    }
}