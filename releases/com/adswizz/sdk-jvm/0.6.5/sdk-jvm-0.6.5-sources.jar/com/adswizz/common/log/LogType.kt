package com.adswizz.common.log

enum class LogType {
    v,
    d,
    i,
    e,
    w;

    override fun toString(): String{
        return when(this){
            w -> "warning"
            d -> "debug"
            i -> "info"
            e -> "error"
            v -> "verbose"
        }
    }
}