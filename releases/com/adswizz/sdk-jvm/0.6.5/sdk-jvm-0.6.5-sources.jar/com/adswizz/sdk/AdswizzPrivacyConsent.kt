package com.adswizz.sdk

import com.adswizz.core.privacy.CCPAConfig
import com.adswizz.core.privacy.GDPRConsent


/**
 * [AdswizzPrivacyConsent] used for encapsulating all consents used by AdswizzSDK.
 */
class AdswizzPrivacyConsent private constructor(
    /**
     * Set the GDPR consent status.
     */
    val gdpr: GDPRConsent = GDPRConsent.NOT_APPLICABLE,
    /**
     * Set the CCPA configuration.
     */
    val ccpa: CCPAConfig = CCPAConfig(),

    /**
     *  Set a TCFv2 string as described by IAB’s Transparency and Consent Framework (TCF).Optional
     */
    val tcfv2: String? = null,

    /**
     * Set gpp consent string
     */
    val gpp: String? = null,

    /**
     * Set GPC ( Global Privacy Control ) value
     */
    val gpc: Boolean = false,
) {
    class Builder{
        var gdpr: GDPRConsent = GDPRConsent.NOT_APPLICABLE
            private set

        var ccpa: CCPAConfig = CCPAConfig()
            private set

        var tcfv2: String? = null
            private set

        var gpp: String? = null
            private set

        var gpc: Boolean = false
            private set

        /**
         * Set the GDPR consent status.
         */

        fun withGDPR(gdpr: GDPRConsent) = apply { this.gdpr = gdpr }

        /**
         * Set the CCPA configuration.
         */
        fun withCCPA(ccpa: CCPAConfig) = apply { this.ccpa = ccpa }

        /**
         *  Set a TCFv2 string as described by IAB’s Transparency and Consent Framework (TCF).Optional
         */
        fun withTCFV2(tcfv2: String) = apply { this.tcfv2 = tcfv2 }

        /**
         * Set gpp consent string
         */
        fun withGPP(gpp: String) = apply { this.gpp = gpp }

        /**
         * Set GPC ( Global Privacy Control ) value
         */
        fun withGPC(gpc: Boolean) = apply { this.gpc = gpc }

        fun build(): AdswizzPrivacyConsent =
            AdswizzPrivacyConsent(
                gdpr = gdpr,
                ccpa = ccpa,
                tcfv2 = tcfv2,
                gpp = gpp,
                gpc = gpc
            )
    }
}