package com.adswizz.sdk

import com.ad.core.adData.AdEvent
import com.ad.core.adData.Payload
import com.ad.core.adData.internal.AdDataImpl
import com.ad.core.adData.internal.AdDataSimple
import com.ad.core.adData.internal.ImpressionsAndTrackingsReporting
import com.ad.core.adData.internal.TrackingUrl
import com.ad.core.adFetcher.model.Ad
import com.ad.core.adFetcher.model.Tracking
import com.ad.core.macro.MacroContext
import com.adswizz.common.macro.VASTErrorCode
import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets

class AdswizzTrackingEngine {

//    var impressionsAndTrackingsReporting = ImpressionsAndTrackingsReporting()
//    internal var trackingPositionsOrder = TrackingPositionsOrder()
val impressionsAndTrackingsReporting = ImpressionsAndTrackingsReporting()

    var lastState = 0

    fun started(key: String, payload: ByteArray /*b*/, elapsedTime: Double, macroContext: MacroContext?): ByteArray /*b1*/{
        println("**** started $key")
        println("**** payload size: ${payload.size}")
        getAdDataFromKey(key, payload).let { adData ->
            println("**** started $key ${adData.id}")
//            trackingPositionsOrder.addProgressPositions(
//                adData,
//                adData.duration ?: 0.0
//            )


            impressionsAndTrackingsReporting.reportImpressions(
                adData,
                macroContext
            )

            /*
            trackingPositionsOrder.addProgressPositions(
                adData,
                adData.duration
            )
            */
            val newAdData = AdDataSimple(adData.id, adData.instanceId, adData.duration, emptyList(), adData.listTrackings, emptyList(),emptyList())
            val payload =  Payload.serializeToByteArray(newAdData)
            println("**** new payload size: ${payload.size}")
            return payload
        }
        return payload
    }

    fun error(key: String, payload: ByteArray, elapsedTime: Double, macroContext: MacroContext?): ByteArray {
        val impressionsAndTrackingsReporting = ImpressionsAndTrackingsReporting()
        getAdDataFromKey(key, payload).let { adData ->
            impressionsAndTrackingsReporting.reportErrors(
                adData,
                VASTErrorCode.GENERAL_LINEAR_ERROR,
                macroContext
            )
        }
        println("**** new payload size: ${payload.size}")
        return payload
    }

    fun progress(key: String, payload: ByteArray,elapsedTime: Double, macroContext: MacroContext?): ByteArray{
        val impressionsAndTrackingsReporting = ImpressionsAndTrackingsReporting()
        getAdDataFromKey(key, payload).let { adData ->
            println("**** progress $key ${adData.id}")
            val newAdData = checkQuartile(adData, elapsedTime, macroContext)
            val payload =  Payload.serializeToByteArray(newAdData)
            println("**** new payload size: ${payload.size}")
            return payload
        }
        //if previuous was paused , send event for resume
        return payload
    }


    fun pause(key: String, payload: ByteArray, elapsedTime: Double): ByteArray{
        /***
         *
         */
        val impressionsAndTrackingsReporting = ImpressionsAndTrackingsReporting()
        getAdDataFromKey(key, payload).let { adData ->
            println("**** progress $key ${adData.id}")
            //val newAdData = checkQuartile(adData, elapsedTime)
            //val payload =  Payload.serializeToByteArray(newAdData)
            println("**** new payload size: ${payload.size}")
            return payload
        }
        //if previ
        //send event for pause
        return payload
    }

    fun resume(key: String, payload: ByteArray, elapsedTime: Double): ByteArray{
        val impressionsAndTrackingsReporting = ImpressionsAndTrackingsReporting()
        return payload
    }

    fun ended(key: String, payload: ByteArray, elapsedTime: Double, reason: String, macroContext: MacroContext?): ByteArray{
        //state is defined by the function
        //key identifies adDataImpl
        println("**** ended $key")
        getAdDataFromKey(key, payload)?.let { adData ->
            println("**** ended $key ${adData.id}")
            triggerEventsOnPlayPercent(adData, 1.0, macroContext)
        }
        return payload
    }

    private fun getAdDataFromKey(key: String, payload: ByteArray): AdDataSimple {
        return Payload.deserializeFromByteArray(payload)
    }


    internal fun checkQuartile(adData: AdDataSimple, progress: Double, macroContext: MacroContext?): AdDataSimple{
            val adDuration = adData.duration
            val percent = progress/adDuration
            println("**** $progress $adDuration ${progress/adDuration}")
            //old check checkCurrentAdQuartiles(adDuration.toDouble(DurationUnit.SECONDS))
            val removedEvents = triggerEventsOnPlayPercent(adData, percent, macroContext)
            if (removedEvents.isEmpty()){
                return adData
            }
            else{
                val listTrackingEvents = mutableListOf<TrackingUrl>()
                adData.listTrackings.forEach {
                    if ( removedEvents.find { removed->
                        removed.event ==  it.event
                    } == null ){
                       listTrackingEvents.add(it)
                    }
                }
                val newAdData = adData.copy(listTrackings = listTrackingEvents)
                return newAdData
            }
    }

    internal fun deserializeByteArray(bytes: ByteArray): AdDataImpl {
        val buffer = ByteBuffer.wrap(bytes)

        val idBytes = buffer.int
        val idBuffer = ByteArray(idBytes)
        buffer.get(idBuffer)
        val id = String(idBuffer, StandardCharsets.UTF_8)


        val instanceIdBytes = buffer.int
        val instanceBuffer = ByteArray(instanceIdBytes)
        buffer.get(instanceBuffer)
        val instanceId = String(instanceBuffer, StandardCharsets.UTF_8)

        return AdDataImpl(id = id, inlineAd = Ad(), wrapperAds = listOf()).apply {
            this.instanceId = instanceId
        }
    }


    private fun triggerEventsOnPlayPercent(adData: AdDataSimple, playPercent:Double, macroContext: MacroContext?): List<TrackingUrl>{
        println("**** triggerEventsOnPlayPercent: $playPercent")
        val positionsTriggered = impressionsAndTrackingsReporting.playHeadChanged(adData, playPercent)
        println("**** triggerEventsOnPlayPercent: positions-> ${positionsTriggered?.size}")
        val listPositionsTriggered = mutableListOf<TrackingUrl>()
        positionsTriggered?.let {
            println("**** triggerEventsOnPlayPercent: position-> $it")
            sendEventsForPositions(adData, positions = it, macroContext)
            listPositionsTriggered.addAll(it)
        }
        return listPositionsTriggered
    }

    private fun sendEventsForPositions(ad: AdDataSimple, positions: List<TrackingUrl>, macroContext: MacroContext?) {
        positions.forEach {
            impressionsAndTrackingsReporting.reportTrackings(
                ad,
                it,
                macroContext
            )
        }

    }
}